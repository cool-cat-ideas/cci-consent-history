<?php

header('Location: ../');
exit;
